import 'package:the_library/data/vos/book_type_vo.dart';

List<BookTypeVO> bookTypeList = [
  BookTypeVO("assets/icons/genres.png", "Genres"),
  BookTypeVO("assets/icons/topselling.png", "Top selling"),
  BookTypeVO("assets/icons/newreleases.png", "New releases"),
  BookTypeVO("assets/icons/romance.png", "Romance"),
];
