///Hive types
const int HIVE_TYPE_ID_BUY_VO = 1;
const int HIVE_TYPE_ID_BOOK_VO = 2;
const int HIVE_TYPE_ID_BOOK_LIST_VO = 3;
const int HIVE_TYPE_ID_BOOK_LIST_RESULTS_VO = 4;

///Box Name
const String BOX_NAME_CHANGE_STYLE = "BOX_NAME_CHANGE_STYLE";
const String BOX_NAME_SORT_TYPE = "BOX_NAME_SORT_TYPE";
const String BOX_NAME_BOOK_LIST = "BOX_NAME_BOOK_LIST";
