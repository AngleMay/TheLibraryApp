import 'package:hive/hive.dart';
import 'package:the_library/persistence/daos/hive_constants.dart';

class ChangeStyleDao {
  static final ChangeStyleDao _singleton = ChangeStyleDao._internal();

  factory ChangeStyleDao() {
    return _singleton;
  }

  ChangeStyleDao._internal();

  void saveStyle(bool isList) {
    this.getChangeStyleBox().put(0, isList);
  }

  bool getStyle(){
    return getChangeStyleBox().get(0);
  }

  Box<bool> getChangeStyleBox() {
    return Hive.box<bool>(BOX_NAME_CHANGE_STYLE);
  }
}
