import 'package:flutter/material.dart';
import 'package:the_library/resources/dimens.dart';
import 'package:the_library/widgets/download_status_icon_session.dart';
import 'package:the_library/widgets/sample_text_session.dart';

class BookViewForThreeColumnGrid extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 3 * 180.toDouble(),
      child: GridView.count(
        // Create a grid with 2 columns. If you change the scrollDirection to
        // horizontal, this produces 2 rows.
        crossAxisCount: 3,
        //childAspectRatio: MediaQuery.of(context).size.height / 1400,
        childAspectRatio: 1 / 2,
        // Generate 100 widgets that display their index in the List.
        children: List.generate(20, (index) {
          return ImageViewForGrid(200.0);
        }),
      ),
    );
  }
}

class ImageViewForGrid extends StatelessWidget {
  final double imageHeight;

  ImageViewForGrid(this.imageHeight);

  @override
  Widget build(BuildContext context) {
    return Container(
      //color: Colors.red,
      //height: 400.0,
      margin: EdgeInsets.symmetric(
        horizontal: MARGIN_MEDIUM,
        vertical: MARGIN_MEDIUM,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: MARGIN_SMALL,
          ),
          ImageViewSession(imageHeight),
          SizedBox(
            height: MARGIN_SMALL,
          ),
          Text(
            "H.P.Lovecraft: The Ultimate Collection(160 Works Including Early Writings,Fiction,Collaborations,Poetry,Essays & Bonus Audiobook links",
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: Colors.black54,
            ),
          ),
          SizedBox(
            height: MARGIN_SMALL,
          ),
          Text(
            "d22,782.00",
            style: TextStyle(
              color: Colors.black54,
            ),
          )
        ],
      ),
    );
  }
}

class ImageViewSession extends StatelessWidget {
  final double imageHeight;

  ImageViewSession(this.imageHeight);

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Align(
          alignment: Alignment.center,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10.0),
            child: Image.network(
              "https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1567519713l/43801263.jpg",
              fit: BoxFit.cover,
              height: imageHeight,
            ),
          ),
        ),
        Align(
          alignment: Alignment.topLeft,
          child: Container(
            margin: EdgeInsets.symmetric(
              horizontal: 5.0,
              vertical: 5.0,
            ),
            child: SampleTextSession(),
          ),
        ),
        Positioned(
          top: 165,
          left: 85,
          right: 0,
          bottom: 0,
          child: Container(
            margin: EdgeInsets.symmetric(
              horizontal: 5.0,
              vertical: 5.0,
            ),
            child: DownloadStatusIconSession(),
          ),
        ),
      ],
    );
  }
}
