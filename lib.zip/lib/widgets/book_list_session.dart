import 'package:flutter/material.dart';
import 'package:the_library/data/vos/book_vo.dart';
import 'package:the_library/resources/dimens.dart';

class BookListSession extends StatelessWidget {
  final BookVO book;
  final Function onTab;
  BookListSession(this.onTab(),{this.book});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: MARGIN_MEDIUM_2),
      child: GestureDetector(
        onTap: () => this.onTab(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(15.0),
              child: Image.network(
                book.bookImage,
                height: 250.0,
              ),
            ),
            SizedBox(
              height: MARGIN_SMALL,
            ),
            Text(
              "Pokok-Pokok Hukum Perpajakan",
              style: TextStyle(
                color: Colors.black54,
              ),
            ),
            SizedBox(
              height: MARGIN_SMALL,
            ),
            Text(
              "Angger Sigit Pramukti",
              style: TextStyle(
                color: Colors.black54,
              ),
            ),
            SizedBox(
              height: MARGIN_SMALL,
            ),
            Row(
              children: [
                Text(
                  "5.0",
                  style: TextStyle(
                    color: Colors.black54,
                  ),
                ),
                Icon(
                  Icons.star,
                  size: 10.0,
                  color: Colors.black54,
                ),
                Text(
                  "IDR 22,000.00",
                  style: TextStyle(
                    color: Colors.black54,
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
