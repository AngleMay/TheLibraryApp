import 'package:flutter/material.dart';
import 'package:the_library/resources/dimens.dart';

class BookViewForGrid extends StatelessWidget {

  final double imageHeight;

  BookViewForGrid(this.imageHeight);

  @override
  Widget build(BuildContext context) {
    return Container(
      //color: Colors.red,
      //height: 400.0,
      margin: EdgeInsets.symmetric(
        horizontal: MARGIN_MEDIUM,
        vertical: MARGIN_MEDIUM,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: MARGIN_SMALL,
          ),
          Image.network(
            "https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1567519713l/43801263.jpg",
            fit: BoxFit.cover,
            height: imageHeight,
          ),
          SizedBox(
            height: MARGIN_SMALL,
          ),
          Text(
            "H.P.Lovecraft: The Ultimate Collection(160 Works Including Early Writings,Fiction,Collaborations,Poetry,Essays & Bonus Audiobook links",
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: Colors.black54,
            ),
          ),
          SizedBox(
            height: MARGIN_SMALL,
          ),
          Text(
            "d22,782.00",
            style: TextStyle(
              color: Colors.black54,
            ),
          )
        ],
      ),
    );
  }
}
