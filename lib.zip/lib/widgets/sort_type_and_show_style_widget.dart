import 'package:flutter/material.dart';
import 'package:the_library/resources/dimens.dart';

class SortByRowView extends StatelessWidget {
  final bool isList;
  final Function changeStyle;
  final Function onTabSort;
  final List<String> sortType;
  final int sortTypeIndex;

  SortByRowView(this.isList, this.sortType, this.sortTypeIndex,
      this.changeStyle(), this.onTabSort());

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        GestureDetector(
          onTap: () => onTabSort(),
          child: Row(
            children: [
              Row(
                children: [
                  Text(
                    "Sort by: ${sortType[sortTypeIndex]}",
                    style: TextStyle(color: Colors.black54),
                  ),
                  SizedBox(
                    width: MARGIN_SMALL,
                  ),
                  Icon(
                    Icons.sort,
                    color: Colors.black54,
                  )
                ],
              ),
            ],
          ),
        ),
        Spacer(),
        GestureDetector(
          onTap: () => this.changeStyle(),
          child: Row(
            children: [
              isList
                  ? Text(
                "View: List",
                style: TextStyle(color: Colors.black54),
              )
                  : Text(
                "View: Grid",
                style: TextStyle(color: Colors.black54),
              ),
              SizedBox(
                width: MARGIN_SMALL,
              ),
              Icon(
                Icons.grid_on_sharp,
                color: Colors.black54,
              ),
            ],
          ),
        ),
      ],
    );
  }
}