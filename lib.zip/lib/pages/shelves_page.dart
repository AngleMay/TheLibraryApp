import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:the_library/pages/create_shelf.dart';
import 'package:the_library/pages/shelf_details.dart';
import 'package:the_library/resources/dimens.dart';

class ShelvesPage extends StatelessWidget {
  _navigateToCreateShelf(BuildContext context) {
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => CreateShelf()));
  }

  _navigateToShelfDetails(BuildContext context) {
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => ShelfDetails()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Align(
            alignment: Alignment.center,
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                //ShelveListView(),
                Container(
                  height: 3 * 180.toDouble(),
                  //width: MediaQuery.of(context).size.width,
                  child: ListView.builder(
                      scrollDirection: Axis.vertical,
                      itemCount: 10,
                      itemBuilder: (context, index) {
                        return ShelveListView(
                            () => _navigateToShelfDetails(context));
                      }),
                ),
              ],
            ),
          ),
          Positioned(
            //bottom: 20,
            top: 550,
            left: 140,
            child: FloatingActionButton.extended(
              onPressed: () => _navigateToCreateShelf(context),
              label: Text("Create new"),
              icon: Icon(
                Icons.create,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class ShelveListView extends StatelessWidget {
  final Function onTab;
  ShelveListView(this.onTab());

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Align(
          alignment: Alignment.center,
          child: ShelfListTileSession(() => this.onTab()),
        ),
        HorizontalLineSession(),
      ],
    );
  }
}

class HorizontalLineSession extends StatelessWidget {
  const HorizontalLineSession({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Positioned(
      bottom: 6,
      left: 17.0,
      child: Container(
        width: MediaQuery.of(context).size.width,
        height: 2.0,
        color: Colors.black12,
      ),
    );
  }
}

class ShelfListTileSession extends StatelessWidget {
  final Function onTabShelf;

  ShelfListTileSession(this.onTabShelf);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => onTabShelf(),
      child: ListTile(
        leading: Image.asset(
          "assets/images/emptyBook.png",
          //height: 200,
        ),
        title: Text(
          "novel",
          style: TextStyle(fontWeight: FontWeight.w500),
        ),
        subtitle: Text("1 book"),
        trailing: Icon(
          Icons.arrow_forward_outlined,
          color: Colors.blue,
        ),
      ),
    );
  }
}
