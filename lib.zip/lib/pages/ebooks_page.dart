import 'package:flutter/material.dart';
import 'package:the_library/data/vos/book_list_vo.dart';
import 'package:the_library/pages/book_details.dart';
import 'package:the_library/pages/book_details_list.dart';
import 'package:the_library/pages/home_page.dart';

class EBooksPage extends StatelessWidget {
  final List<BookListVO> bookList;
  EBooksPage(this.bookList);

  _navigateToBookDetailList(BuildContext context, String title) {
    Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => BookDetailsListPage(title)),
        (Route<dynamic> route) => false);
  }

  _navigateToBookDetail(BuildContext context) {
    Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => BookDetails()),
        (Route<dynamic> route) => false);
    // Navigator.push(
    //   context,
    //   MaterialPageRoute(
    //     builder: (context) => BookDetails(),
    //   ),
    // );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      //height: 5.7 * 360.toDouble(),
      child: ListView.builder(
          scrollDirection: Axis.vertical,
          itemCount: bookList.length,
          shrinkWrap: true,
          itemBuilder: (context, index) {
            return MoreLikeBookListSession(
                bookList[index].displayName,
                bookList[index],
                () => _navigateToBookDetailList(
                    context, bookList[index].displayName),
                () => _navigateToBookDetail(context));
          }),
    );
  }
}
