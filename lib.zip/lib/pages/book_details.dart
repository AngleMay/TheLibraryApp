import 'package:flutter/material.dart';
import 'package:the_library/pages/home_tab_page.dart';
import 'package:the_library/resources/dimens.dart';
import 'package:the_library/widgets/back_button_view.dart';
import 'package:the_library/widgets/book_list_session.dart';
import 'package:the_library/widgets/book_view_for_grid.dart';
import 'package:the_library/widgets/rating_view.dart';

class BookDetails extends StatelessWidget {
  List<int> ratingBar = [5, 4, 3, 2, 1];

  _navigatorToHomeTabPage(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => HomeTabPage(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        leading: LeftButtonSession(
          Colors.black54,
          () => _navigatorToHomeTabPage(context),
        ),
        actions: [
          AppBarActionView(),
          SizedBox(
            width: MARGIN_MEDIUM,
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Container(
          height: 1000.0,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              BookDetailsHeaderSession(),
              SizedBox(
                height: MARGIN_SMALL,
              ),
              RatingBarSession(),
              SizedBox(
                height: MARGIN_MEDIUM_2,
              ),
              PriceButtonSession(),
              SizedBox(
                height: MARGIN_SMALL,
              ),
              horizontalLineSession(),
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: MARGIN_MEDIUM_2,
                  vertical: MARGIN_MEDIUM_2,
                ),
                child: Column(
                  children: [
                    AboutBookSession(),
                    SizedBox(
                      height: MARGIN_MEDIUM_2,
                    ),
                    RatingAndReviewSession(ratingBar: ratingBar)
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: MARGIN_MEDIUM_2,
                ),
                child: HeaderLineSession("Similar EBooks"),
              ),
              SizedBox(
                height: MARGIN_MEDIUM_2,
              ),
              Expanded(
                child: Container(
                  height: 300.0,
                  child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: 10,
                      itemBuilder: (context, index) {
                        return BookListSession(() {});
                      }),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class AboutBookSession extends StatelessWidget {
  const AboutBookSession({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        HeaderLineSession("About this eBook"),
        SizedBox(
          height: MARGIN_MEDIUM,
        ),
        Text(
          "Pengawasan hukum terhadap aparatur negara / Angger Sigit Pramukti, Meylani Chahyaningsih ; penyunting, Tri Admojo Pengawasan hukum terhadap aparatur negara / Angger Sigit Pramukti, Meylani Chahyaningsih ; penyunting, Tri AdmojoPengawasan hukum terhadap aparatur negara / Angger Sigit Pramukti, Meylani Chahyaningsih ; penyunting, Tri Admojo Pengawasan hukum terhadap aparatur negara / Angger Sigit Pramukti, Meylani Chahyaningsih ; penyunting, Tri Admojo ",
          maxLines: 4,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontSize: 15.0,
            color: Colors.black54,
          ),
        ),
      ],
    );
  }
}

class RatingAndReviewSession extends StatelessWidget {
  const RatingAndReviewSession({
    Key key,
    @required this.ratingBar,
  }) : super(key: key);

  final List<int> ratingBar;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        HeaderLineSession("Ratings and reviews"),
        Row(
          children: [
            Column(
              children: [
                Text(
                  "5.0",
                  style: TextStyle(
                    fontSize: 60.0,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(
                  height: MARGIN_MEDIUM,
                ),
                RatingView(),
                SizedBox(
                  height: MARGIN_MEDIUM,
                ),
                Text("6 total"),
              ],
            ),
            SizedBox(
              width: MARGIN_MEDIUM_3,
            ),
            Column(
              children: ratingBar.map((bar) {
                return Row(
                  children: [
                    Text(bar.toString()),
                    SizedBox(
                      width: MARGIN_MEDIUM_2,
                    ),
                    Container(
                      width: 200.0,
                      height: 5.0,
                      child: LinearProgressIndicator(
                        backgroundColor: Colors.black54,
                        valueColor:
                            new AlwaysStoppedAnimation<Color>(Colors.blue),
                        value: 1.0,
                      ),
                    )
                  ],
                );
              }).toList(),
            )
          ],
        )
      ],
    );
  }
}

class HeaderLineSession extends StatelessWidget {
  final String title;

  HeaderLineSession(this.title);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: TEXT_REGULAR_4X,
            fontWeight: FontWeight.w600,
          ),
        ),
        Spacer(),
        Icon(
          Icons.arrow_forward_outlined,
          color: Colors.blue,
          size: 23.0,
        ),
      ],
    );
  }
}

class horizontalLineSession extends StatelessWidget {
  const horizontalLineSession({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width / 1.1,
      height: 1.0,
      color: Colors.black26,
    );
  }
}

class PriceButtonSession extends StatelessWidget {
  const PriceButtonSession({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.max,
      children: [
        Container(
          width: MediaQuery.of(context).size.width / 2.3,
          height: 40.0,
          margin: EdgeInsets.symmetric(
            horizontal: MARGIN_MEDIUM_2,
            vertical: MARGIN_MEDIUM_2,
          ),
          decoration: BoxDecoration(
            border: Border.all(
              color: Colors.black26,
            ),
            borderRadius: BorderRadius.circular(10.0),
          ),
          child: FlatButton(
            onPressed: () {},
            child: Text(
              "Free Sample",
              style: TextStyle(
                color: Colors.blue,
              ),
            ),
          ),
        ),
        // SizedBox(
        //   width: MARGIN_MEDIUM_2,
        // ),
        Container(
          width: MediaQuery.of(context).size.width / 2.3,
          height: 40.0,
          margin: EdgeInsets.symmetric(
              //horizontal: MARGIN_MEDIUM_2,
              //vertical: MARGIN_MEDIUM_2,
              ),
          decoration: BoxDecoration(
            border: Border.all(
              color: Colors.black12,
            ),
            borderRadius: BorderRadius.circular(10.0),
            color: Colors.blue,
          ),
          child: FlatButton(
            onPressed: () {},
            child: Text(
              "Buy THB 44.79",
              style: TextStyle(color: Colors.white),
            ),
          ),
        ),
      ],
    );
  }
}

class RatingBarSession extends StatelessWidget {
  @override
  @override
  Widget build(BuildContext context) {
    return Rating();
  }
}

class Rating extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: MediaQuery.of(context).size.width * 0.33,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    "5.0",
                    style: TextStyle(
                      fontSize: 18.0,
                      color: Colors.black54,
                    ),
                  ),
                  SizedBox(
                    width: MARGIN_SMALL,
                  ),
                  Icon(
                    Icons.star,
                    color: Colors.black54,
                  )
                ],
              ),
              SizedBox(
                height: MARGIN_SMALL,
              ),
              Text(
                "6 reviews",
                style: TextStyle(
                  fontSize: 16.0,
                  color: Colors.black54,
                ),
              ),
            ],
          ),
        ),
        Container(
          decoration: BoxDecoration(
            border: Border.symmetric(
              vertical: BorderSide(color: Colors.black54),
            ),
          ),
          width: MediaQuery.of(context).size.width * 0.33,
          child: Column(
            children: [
              Icon(
                Icons.bookmark_border,
                color: Colors.black54,
              ),
              SizedBox(
                height: MARGIN_SMALL,
              ),
              Text(
                "eBook",
                style: TextStyle(
                  fontSize: 16.0,
                  color: Colors.black54,
                ),
              )
            ],
          ),
        ),
        Container(
          width: MediaQuery.of(context).size.width * 0.33,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                "160",
                style: TextStyle(
                  fontSize: 16.0,
                  color: Colors.black54,
                ),
              ),
              SizedBox(
                height: MARGIN_SMALL,
              ),
              Text(
                "Pages",
                style: TextStyle(
                  fontSize: 16.0,
                  color: Colors.black54,
                ),
              )
            ],
          ),
        )
      ],
    );
  }
}

class BookDetailsHeaderSession extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.max,
      children: [
        // SizedBox(
        //   width: MARGIN_MEDIUM_2,height: MARGIN_MEDIUM_2,
        // ),
        Padding(
          padding: const EdgeInsets.symmetric(
              horizontal: MARGIN_MEDIUM_2, vertical: MARGIN_MEDIUM_2),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10.0),
            child: Image.network(
              "https://images-na.ssl-images-amazon.com/images/I/71WwqFIHqZL.jpg",
              height: 200.0,
            ),
          ),
        ),
        // SizedBox(
        //   width: MARGIN_MEDIUM_2,
        // ),
        Container(
          width: 230.0,
          height: 170.0,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "POkok-Pokok Hukum Perpajakan",
                maxLines: 2,
                textDirection: TextDirection.ltr,
                textHeightBehavior:
                    TextHeightBehavior(applyHeightToFirstAscent: true),
                style: TextStyle(
                  fontSize: 25.0,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(
                height: MARGIN_MEDIUM,
              ),
              Text(
                "Angger Sigit Pramukti,S.H. & Fuady Pri",
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: Colors.black54, fontSize: 15.0),
              ),
              SizedBox(
                height: MARGIN_MEDIUM,
              ),
              Text(
                "Media Possindo",
                style: TextStyle(color: Colors.black54, fontSize: 15.0),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class AppBarActionView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          Icons.search,
          color: Colors.black54,
        ),
        SizedBox(
          width: MARGIN_MEDIUM_2,
        ),
        Icon(
          Icons.bookmark_outline_sharp,
          color: Colors.black54,
        ),
        SizedBox(
          width: MARGIN_MEDIUM_2,
        ),
        Icon(
          Icons.more_vert,
          color: Colors.black54,
        ),
      ],
    );
  }
}
