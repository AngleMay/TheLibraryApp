import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:the_library/blocs/search_bloc.dart';
import 'package:the_library/debouncer.dart';
import 'package:the_library/resources/dimens.dart';

class SearchPage extends StatelessWidget {
  TextEditingController searchVal = new TextEditingController();
  final _deBouncer = Debouncer(milliseconds: 1000);

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => SearchBloc(),
      child: Scaffold(
        appBar: AppBar(
          toolbarHeight: 10.0,
          elevation: 0,
          backgroundColor: Colors.white,
        ),
        body: Container(
          color: Colors.white,
          child: Column(
            children: [
              Selector<SearchBloc, String>(
                  selector: (context, bloc) => bloc.searchText,
                  builder: (context, searchText, child) {
                    return Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(
                          width: MARGIN_MEDIUM_2,
                        ),
                        IconButton(
                          onPressed: () => Navigator.pop(context),
                          icon: Icon(
                            Icons.arrow_back,
                          ),
                        ),
                        SizedBox(
                          width: MARGIN_MEDIUM_2,
                        ),
                        // Selector<SearchBloc, String>(
                        //   selector: (context, bloc) => bloc.searchText,
                        //   builder: (context, bloc, child) {
                        Expanded(
                          child: TextField(
                            //onChanged: () => onTextChange(searchVal.text) ,
                            // onTap: () {
                            //   SearchBloc bloc = Provider.of<SearchBloc>(
                            //     context,
                            //     listen: true,
                            //   );
                            //   bloc.onTextChange(searchVal.text);
                            // },
                            onChanged: (String val) {
                              _deBouncer.run(() {
                                print(val.toString());
                              });
                            },
                            controller: searchVal,
                            autofocus: true,
                            decoration: InputDecoration(
                              hintText: "Search Play Books",
                              border: InputBorder.none,
                              focusedBorder: InputBorder.none,
                            ),
                          ),
                        ),
                        //   },
                        // ),
                        SizedBox(
                          width: MARGIN_MEDIUM_2,
                        ),
                        searchVal.text != null
                            ? Icon(
                                Icons.clear,
                              )
                            : Container(),
                        SizedBox(
                          width: MARGIN_MEDIUM_2,
                        ),
                        Icon(
                          Icons.mic,
                        ),
                        SizedBox(
                          width: MARGIN_MEDIUM_2,
                        ),
                      ],
                    );
                  }),
              Divider(
                color: Colors.black26,
              ),
              Expanded(
                //height: 1000.0,
                //width: MediaQuery.of(context).size.width,
                child: ListView.builder(
                    scrollDirection: Axis.vertical,
                    itemCount: 5,
                    itemBuilder: (context, index) {
                      return ListTile(
                        leading: Image.asset("assets/icons/clock_icon.png"),
                        title: Text("after"),
                      );
                    }),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: MARGIN_MEDIUM_2,
                  ),
                  child: ListTile(
                    leading: Image.network(
                      "https://images-na.ssl-images-amazon.com/images/I/71WwqFIHqZL.jpg",
                    ),
                    title: Text("Good to Great"),
                    subtitle: Text("Jim Collins * audiobook in your library"),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
