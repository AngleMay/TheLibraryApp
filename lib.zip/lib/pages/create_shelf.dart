import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:the_library/blocs/shelf_details_bloc.dart';
import 'package:the_library/pages/your_books_page.dart';
import 'package:the_library/resources/dimens.dart';
import 'package:the_library/widgets/BookViewForThreeColumnGrid.dart';
import 'package:the_library/widgets/book_list_view.dart';
import 'package:the_library/widgets/sort_type_and_show_style_widget.dart';

class CreateShelf extends StatelessWidget {
  final TextEditingController shelfName;
  final List<String> sortType = ["Author", "Recent", "Title"];
  CreateShelf({this.shelfName});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => ShelfDetailsBloc(),
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          toolbarHeight: 10.0,
        ),
        body: Column(
          children: [
            Container(
              padding: EdgeInsets.symmetric(
                horizontal: MARGIN_MEDIUM_3,
                vertical: MARGIN_MEDIUM_2,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(
                    Icons.done_outlined,
                    color: Colors.blue,
                  ),
                  TextField(
                    cursorHeight: 30.0,
                    autofocus: true,
                    controller: shelfName,
                    decoration: InputDecoration(
                        hintText: "Shelf name",
                        hintStyle: TextStyle(
                          fontSize: 25.0,
                          fontWeight: FontWeight.w500,
                          color: Colors.black54,
                        )),
                  )
                ],
              ),
            ),
            Divider(
              color: Colors.black54,
            ),
            Selector<ShelfDetailsBloc, bool>(
              selector: (context, bloc) => bloc.isList,
              builder: (context, isList, child) {
                return Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: MARGIN_MEDIUM_2,
                        vertical: MARGIN_MEDIUM_2,
                      ),
                      child: Selector<ShelfDetailsBloc, int>(
                        selector: (context, bloc) => bloc.sortTypeIndex,
                        builder: (context, sortTypeIndex, child) {
                          return SortByRowView(isList, sortType, sortTypeIndex,
                              () {
                            ShelfDetailsBloc bookBloc =
                                Provider.of(context, listen: false);
                            bookBloc.changeStyle();
                          }, () {
                            ShelfDetailsBloc bookBloc =
                                Provider.of(context, listen: false);
                            bookBloc.onTabSort(context, sortTypeIndex);
                          });
                        },
                      ),
                    ),
                    isList ? BookViewForThreeColumnGrid() : BookListView(),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
