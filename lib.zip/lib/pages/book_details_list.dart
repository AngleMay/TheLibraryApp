import 'package:flutter/material.dart';
import 'package:the_library/pages/home_page.dart';
import 'package:the_library/pages/home_tab_page.dart';
import 'package:the_library/resources/dimens.dart';
import 'package:the_library/widgets/back_button_view.dart';
import 'package:the_library/widgets/book_view_for_grid.dart';

class BookDetailsListPage extends StatelessWidget {
  final String title;

  BookDetailsListPage(this.title);

  _navigatorToHomePage(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => HomeTabPage(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        //elevation: 0,
        backgroundColor: Colors.white,
        title: Text(
          this.title,
          style: TextStyle(color: Colors.black87),
        ),
        leading: LeftButtonSession(
          Colors.black87,
          () => _navigatorToHomePage(context),
        ),
        // leading: Icon(
        //   Icons.arrow_back,
        //   color: Colors.black87,
        // ),
        //toolbarHeight: MARGIN_MEDIUM,
      ),
      body: GridView.count(
        // Create a grid with 2 columns. If you change the scrollDirection to
        // horizontal, this produces 2 rows.
        crossAxisCount: 2,
        childAspectRatio: MediaQuery.of(context).size.height / 1400,
        // Generate 100 widgets that display their index in the List.
        children: List.generate(20, (index) {
          return BookViewForGrid(300.0);
        }),
      ),
    );
  }
}


