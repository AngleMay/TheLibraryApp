import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:the_library/blocs/your_books_bloc.dart';
import 'package:the_library/resources/dimens.dart';
import 'package:the_library/widgets/BookViewForThreeColumnGrid.dart';
import 'package:the_library/widgets/book_list_view.dart';
import 'package:the_library/widgets/book_view_for_grid.dart';
import 'package:the_library/widgets/sample_book_session_view.dart';
import 'package:the_library/widgets/sort_type_and_show_style_widget.dart';

class YourBooksPage extends StatelessWidget {
  final List<String> sortType = ["Author", "Recent", "Title"];
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => YourBooksBloc(),
      child: Scaffold(
        body: Selector<YourBooksBloc, bool>(
          selector: (context, bloc) => bloc.isList,
          builder: (context, isList, child) {
            return Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: MARGIN_MEDIUM_2,
                    vertical: MARGIN_MEDIUM_2,
                  ),
                  child: Selector<YourBooksBloc, int>(
                    selector: (context, bloc) => bloc.sortTypeIndex,
                    builder: (context, sortTypeIndex, child) {
                      return SortByRowView(isList, sortType, sortTypeIndex, () {
                        YourBooksBloc bookBloc =
                            Provider.of(context, listen: false);
                        bookBloc.changeStyle();
                      }, () {
                        YourBooksBloc bookBloc =
                            Provider.of(context, listen: false);
                        bookBloc.onTabSort(context, sortTypeIndex);
                      });
                    },
                  ),
                ),
                isList ? BookViewForThreeColumnGrid() : BookListView(),
              ],
            );
          },
        ),
      ),
    );
  }
}


// class SortByRowView extends StatelessWidget {
//   final bool isList;
//   final Function changeStyle;
//   final Function onTabSort;
//   final List<String> sortType;
//   final int sortTypeIndex;
//
//   SortByRowView(this.isList, this.sortType, this.sortTypeIndex,
//       this.changeStyle(), this.onTabSort());
//
//   @override
//   Widget build(BuildContext context) {
//     return Row(
//       children: [
//         GestureDetector(
//           onTap: () => onTabSort(),
//           child: Row(
//             children: [
//               Row(
//                 children: [
//                   Text(
//                     "Sort by: ${sortType[sortTypeIndex]}",
//                     style: TextStyle(color: Colors.black54),
//                   ),
//                   SizedBox(
//                     width: MARGIN_SMALL,
//                   ),
//                   Icon(
//                     Icons.sort,
//                     color: Colors.black54,
//                   )
//                 ],
//               ),
//             ],
//           ),
//         ),
//         Spacer(),
//         GestureDetector(
//           onTap: () => this.changeStyle(),
//           child: Row(
//             children: [
//               isList
//                   ? Text(
//                       "View: List",
//                       style: TextStyle(color: Colors.black54),
//                     )
//                   : Text(
//                       "View: Grid",
//                       style: TextStyle(color: Colors.black54),
//                     ),
//               SizedBox(
//                 width: MARGIN_SMALL,
//               ),
//               Icon(
//                 Icons.grid_on_sharp,
//                 color: Colors.black54,
//               ),
//             ],
//           ),
//         ),
//       ],
//     );
//   }
// }
