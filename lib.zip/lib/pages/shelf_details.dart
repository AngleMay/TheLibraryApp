import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:the_library/blocs/shelf_details_bloc.dart';
import 'package:the_library/pages/create_shelf.dart';
import 'package:the_library/pages/your_books_page.dart';
import 'package:the_library/resources/dimens.dart';
import 'package:the_library/widgets/BookViewForThreeColumnGrid.dart';
import 'package:the_library/widgets/book_list_view.dart';
import 'package:the_library/widgets/sort_type_and_show_style_widget.dart';

class ShelfDetails extends StatelessWidget {
  final List<String> sortType = ["Author", "Recent", "Title"];
  final List<String> popupRoutes = <String>[
    "Rename shelf",
    "Delete shelf",
  ];

  TextEditingController shelfName = new TextEditingController();

  _morePopupView(BuildContext context) {
    showMenu<String>(
        context: context,
        position: RelativeRect.fromLTRB(200.0, 10.0, 5.0, 100.0),
        items: popupRoutes.map((item) {
          return PopupMenuItem<String>(
            child: ListTile(
              title: Text("$item"),
              onTap: () => _chooseShelf(context, item),
            ),
          );
        }).toList());
    // PopupMenuButton(
    //   color: Colors.yellowAccent,
    //   elevation: 20,
    //   enabled: true,
    //   onCanceled: () {
    //     //do something
    //   },
    //   shape: OutlineInputBorder(
    //       borderSide: BorderSide(color: Colors.grey, width: 2)),
    //     itemBuilder:(context) => [
    //       PopupMenuItem(
    //         child: Text("First"),
    //         value: 1,
    //       ),
    //       PopupMenuItem(
    //         child: Text("Second"),
    //         value: 2,
    //       ),
    //     ]
    //   // itemBuilder: (context) => [
    //   //   PopupMenuItem(
    //   //     child: Text("Rename shelf"),
    //   //     value: 1,
    //   //   ),
    //   //   PopupMenuItem(
    //   //     child: Text("Delete shelf"),
    //   //     value: 2,
    //   //   ),
    //   // ],
    // );
  }

  _chooseShelf(BuildContext context, String chooseItem) {
    shelfName.text = "novel";
    String name = shelfName.text;
    Navigator.pop(context);
    if (chooseItem == "Delete shelf") {
      showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDeleteBoxSession(name: name);
          });
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => CreateShelf(
            shelfName: shelfName,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => ShelfDetailsBloc(),
      child: Scaffold(
        appBar: AppBar(
          //toolbarHeight: 100.0,
          elevation: 0,
          backgroundColor: Colors.white10,
          leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: Icon(
              Icons.arrow_back,
              color: Colors.black54,
            ),
          ),
          actions: [
            Icon(
              Icons.search,
              color: Colors.black54,
            ),
            SizedBox(
              width: MARGIN_MEDIUM,
            ),
            IconButton(
                onPressed: () => _morePopupView(context),
                icon: Icon(
                  Icons.more_vert_outlined,
                  color: Colors.black54,
                )),
            SizedBox(
              width: MARGIN_MEDIUM,
            ),
          ],
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              //color: Colors.white,
              padding: EdgeInsets.symmetric(
                horizontal: MARGIN_MEDIUM_2,
              ),
              child: Column(
                children: [
                  Text(
                    "novel",
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 25.0,
                    ),
                  ),
                  SizedBox(
                    height: MARGIN_SMALL,
                  ),
                  Text("1 book"),
                ],
              ),
            ),
            SizedBox(
              height: MARGIN_SMALL,
            ),
            Divider(
              color: Colors.black54,
            ),
            Selector<ShelfDetailsBloc, bool>(
              selector: (context, bloc) => bloc.isList,
              builder: (context, isList, child) {
                return Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: MARGIN_MEDIUM_2,
                        vertical: MARGIN_MEDIUM_2,
                      ),
                      child: Selector<ShelfDetailsBloc, int>(
                        selector: (context, bloc) => bloc.sortTypeIndex,
                        builder: (context, sortTypeIndex, child) {
                          return SortByRowView(isList, sortType, sortTypeIndex,
                              () {
                            ShelfDetailsBloc bookBloc =
                                Provider.of(context, listen: false);
                            bookBloc.changeStyle();
                          }, () {
                            ShelfDetailsBloc bookBloc =
                                Provider.of(context, listen: false);
                            bookBloc.onTabSort(context, sortTypeIndex);
                          });
                        },
                      ),
                    ),
                    isList ? BookViewForThreeColumnGrid() : BookListView(),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class AlertDeleteBoxSession extends StatelessWidget {
  final String name;

  AlertDeleteBoxSession({this.name});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text("Delete  \'$name\' ?"),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Divider(
            color: Colors.black54,
          ),
          SizedBox(
            height: MARGIN_MEDIUM_2,
          ),
          Text(
              "This shelf will be deleted from all of your devices.Purchases,samples,uploads and active rentals on this shelf will stay in 'Your books."),
        ],
      ),
      // content: SingleChildScrollView(
      //   child: ListBody(
      //     children: const <Widget>[
      //       Text('This is a demo alert dialog.'),
      //       Text('Would you like to approve of this message?'),
      //     ],
      //   ),
      // ),
      actions: <Widget>[
        CancelButtonSession(),
        DeleteButtonSession(),
      ],
    );
  }
}

class CancelButtonSession extends StatelessWidget {
  const CancelButtonSession({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return FlatButton(
      child: const Text('Cancel'),
      minWidth: 120.0,
      textColor: Colors.blue,
      shape: RoundedRectangleBorder(
        side: BorderSide(color: Colors.black38),
        borderRadius: BorderRadius.circular(5.0),
      ),
      onPressed: () {
        Navigator.of(context).pop();
      },
    );
  }
}

class DeleteButtonSession extends StatelessWidget {
  const DeleteButtonSession({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return FlatButton(
      child: const Text('Delete'),
      color: Colors.blue,
      minWidth: 180.0,
      textColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(5.0),
      ),
      onPressed: () {},
    );
  }
}
