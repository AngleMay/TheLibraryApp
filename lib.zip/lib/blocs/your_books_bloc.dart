import 'package:flutter/material.dart';
import 'package:the_library/data/models/library_model.dart';
import 'package:the_library/data/models/library_model_impl.dart';
import 'package:the_library/resources/dimens.dart';

class YourBooksBloc extends ChangeNotifier {
  ///state
  bool isList = false;
  int sortTypeIndex = 2;

  ///Model
  LibraryModel libraryModel = LibraryModelImpl();

  void changeStyle() {
    if (this.isList) {
      this.isList = false;
    } else {
      this.isList = true;
    }
    libraryModel.saveStyle(isList);
    notifyListeners();
  }

  void changeSortType(int index) {
    libraryModel.saveSortType(index);
    libraryModel.getSortTypeFromDatabase().then((index) {
      this.sortTypeIndex = index;
      notifyListeners();
    });
  }

  void onTabSort(BuildContext context, int index) {
    showModalBottomSheet(
        context: context,
        builder: (context) {
          return Container(
            width: MediaQuery.of(context).size.width,
            height: 250.0,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: MARGIN_MEDIUM_3,
                    vertical: MARGIN_MEDIUM_2,
                  ),
                  child: Text(
                    "Sort by",
                    style:
                        TextStyle(fontWeight: FontWeight.w600, fontSize: 20.0),
                  ),
                ),
                Divider(
                  color: Colors.grey,
                ),
                ListTile(
                  title: Text("Author"),
                  leading: Column(
                    children: [
                      Radio(
                        onChanged: (value) {
                          Navigator.pop(context);
                          changeSortType(value);
                        },
                        groupValue: index,
                        value: 0,
                        activeColor: Colors.blue,
                      ),
                    ],
                  ),
                ),
                ListTile(
                  title: Text("Recent"),
                  leading: Column(
                    children: [
                      Radio(
                        onChanged: (value) {
                          Navigator.pop(context);
                          changeSortType(value);
                        },
                        groupValue: index,
                        value: 1,
                        activeColor: Colors.blue,
                      ),
                    ],
                  ),
                ),
                ListTile(
                  title: Text("Title"),
                  leading: Column(
                    children: [
                      Radio(
                        onChanged: (value) {
                          Navigator.pop(context);
                          changeSortType(value);
                        },
                        groupValue: index,
                        value: 2,
                        activeColor: Colors.blue,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        });
  }

  YourBooksBloc() {
    libraryModel.saveStyle(false);
    libraryModel.saveSortType(2);
    changeStyle();
  }
}
