import 'package:flutter/cupertino.dart';
import 'package:the_library/data/models/library_model.dart';
import 'package:the_library/data/models/library_model_impl.dart';
import 'package:the_library/data/vos/book_list_vo.dart';

class HomeBloc extends ChangeNotifier {
  ///state
  List<BookListVO> bookList;

  ///Model
  LibraryModel libraryModel = LibraryModelImpl();

  //constructor
  HomeBloc() {
    libraryModel.saveStyle(true);

    ///NowPlaying Movie From Database
    // mMovieModel.getNowPlayingMoviesFromDatabase().listen((nowPlayingMovie) {
    //   mNowPlayingMovieList = nowPlayingMovie;
    //   notifyListeners();
    // }).onError((error) {});

    ///book list
    libraryModel.getBookListFromDatabase().listen((books) {
      bookList = books;
      notifyListeners();
    }).onError((error) {});
  }
}
