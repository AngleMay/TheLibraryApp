import 'package:flutter/cupertino.dart';


class SearchBloc extends ChangeNotifier {
  ///State
  String searchText;


  String onTextChange(String text) {

    searchText = text;
    notifyListeners();
    return text;
  }
}
