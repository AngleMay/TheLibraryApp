class BookTypeVO {
  String icon;
  String type;

  BookTypeVO(this.icon, this.type);
}
