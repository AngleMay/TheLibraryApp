import 'package:the_library/data/vos/book_list_vo.dart';

abstract class LibraryModel {
  ///Network
  String getTodayData();
  void getBookList();

  ///Database
  void saveStyle(bool isList);
  Future<bool> getStyleFromDatabase();
  void saveSortType(int sortTypeIndex);
  Future<int> getSortTypeFromDatabase();
  Stream<List<BookListVO>> getBookListFromDatabase();
}