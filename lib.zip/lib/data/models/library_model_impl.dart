import 'package:the_library/data/models/library_model.dart';
import 'package:the_library/data/vos/book_list_vo.dart';
import 'package:the_library/network/library_data_agent.dart';
import 'package:the_library/network/retrofit_data_agent_impl.dart';
import 'package:the_library/persistence/daos/book_list_dao.dart';
import 'package:the_library/persistence/daos/chang_style_dao.dart';
import 'package:the_library/persistence/daos/sort_type_dao.dart';
import 'package:stream_transform/stream_transform.dart';
import 'package:intl/intl.dart';

class LibraryModelImpl extends LibraryModel {
  static final LibraryModelImpl _singleton = LibraryModelImpl._internal();

  factory LibraryModelImpl() {
    return _singleton;
  }

  LibraryModelImpl._internal() {}

  LibraryDataAgent lDataAgent = new RetrofitDataAgentImpl();

  ///Dao
  ChangeStyleDao styleDao = new ChangeStyleDao();
  SortTypeDao sortTypeDao = new SortTypeDao();
  BookListDao bBookListDao = new BookListDao();

  @override
  String getTodayData() {
    // var date = new DateTime.now().toString();
    // var dateParse = DateTime.parse(date);
    // var formattedData = "${dateParse.year}-${dateParse.month}-${dateParse.day}";
    // return formattedData;
    final DateTime now = DateTime.now();
    final DateFormat formatter = DateFormat('yyyy-MM-dd');
    final String formatted = formatter.format(now);
    print(formatted);
    return formatted;
  }

  ///Network
  @override
  void getBookList() async {
    String publishedDate = getTodayData();
    Future.value(lDataAgent.getBookList(publishedDate).then((bookListResult) {
      bBookListDao.saveAllBooksList(bookListResult.lists);
    }));

    // List<MovieVO> mMovies = movies.map((movie) {
    //   movie.isComingSoon = false;
    //   movie.isNowShowing = true;
    //   return movie;
    // }).toList();
    // mMovieDao.saveAllMovies(mMovies);
    // return Future.value(movies);
  }

  ///Database
  @override
  Future<bool> getStyleFromDatabase() {
    return Future.value(styleDao.getStyle());
  }

  @override
  void saveStyle(bool isList) {
    styleDao.saveStyle(isList);
  }

  @override
  Future<int> getSortTypeFromDatabase() {
    return Future.value(sortTypeDao.getSortType());
  }

  @override
  void saveSortType(int sortTypeIndex) {
    sortTypeDao.saveSortType(sortTypeIndex);
  }

  @override
  Stream<List<BookListVO>> getBookListFromDatabase() {
    this.getBookList();
    return bBookListDao
        .getAllBookListStream()
        .startWith(bBookListDao.getBookListStream())
        .map((event) => bBookListDao.getBookList());
  }
}
