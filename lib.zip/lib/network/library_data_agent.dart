import 'package:the_library/data/vos/book_list_results_vo.dart';

abstract class LibraryDataAgent{
    Future<BookListResultsVO> getBookList(String publishedDate);
}