
///Base Url
const String BASE_URL_DIO = "https://api.nytimes.com/svc/books/v3";

///End Point
const String ENDPOINT_GET_BOOK_LIST = "/lists/overview.json";

///Parameter
const String PARAM_API_KEY = "api-key";
const String PARAM_PUBLISHED_DATE = "published_date";

///Constant Values
const String API_KEY = "IZI8Q5kDd7GZr2e3vRat8GUBBwsIhI0d%20";
