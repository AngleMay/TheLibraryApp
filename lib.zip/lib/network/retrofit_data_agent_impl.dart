import 'package:dio/dio.dart';
import 'package:the_library/data/vos/book_list_results_vo.dart';
import 'package:the_library/network/api_constants.dart';
import 'package:the_library/network/library_data_agent.dart';
import 'package:the_library/network/the_library_api.dart';

class RetrofitDataAgentImpl extends LibraryDataAgent {
  TheLibraryApi lApi;

  static final RetrofitDataAgentImpl _singleton =
      RetrofitDataAgentImpl._internal();

  factory RetrofitDataAgentImpl() {
    return _singleton;
  }

  RetrofitDataAgentImpl._internal() {
    Dio dio = Dio();
    lApi = TheLibraryApi(dio);
  }

  @override
  Future<BookListResultsVO> getBookList(String publishedDate) {
    return lApi
        .getBookList(publishedDate,API_KEY)
        .asStream()
        .map((data) => data.results)
        .first;
  }
}
